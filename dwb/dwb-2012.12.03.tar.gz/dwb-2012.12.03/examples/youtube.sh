#!/bin/bash
# dwb: Control y

youtube-dl -o "/tmp/%(title)s.flv" "$DWB_URI"
